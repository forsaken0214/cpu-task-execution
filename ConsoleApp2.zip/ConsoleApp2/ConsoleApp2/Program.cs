﻿using System;
using System.Management;
using System.Threading;

using System.Linq;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using OpenHardwareMonitor.Hardware;

namespace ConsoleApp2
{
    internal class StringDistance
    {
        #region Public Methods

        public static string GenerateRandomString(int length)
        {
            var r = new Random((int)DateTime.Now.Ticks);
            var sb = new StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                int c = r.Next(97, 123);
                sb.Append(Char.ConvertFromUtf32(c));
            }
            return sb.ToString();
        }

        public static int LevenshteinDistance(string str1, string str2)
        {
            var scratchDistanceMatrix = new int[str1.Length + 1, str2.Length + 1];
            // distance matrix contains one extra row and column for the seed values         
            for (int i = 0; i <= str1.Length; i++)
            {
                scratchDistanceMatrix[i, 0] = i;
            }
            for (int j = 0; j <= str2.Length; j++)
            {
                scratchDistanceMatrix[0, j] = j;
            }
            for (int i = 1; i <= str1.Length; i++)
            {
                int str1Index = i - 1;
                for (int j = 1; j <= str2.Length; j++)
                {
                    int str2Index = j - 1;
                    int cost = (str1[str1Index] == str2[str2Index]) ? 0 : 1;
                    int deletion = (i == 0) ? 1 : scratchDistanceMatrix[i - 1, j] + 1;
                    int insertion = (j == 0) ? 1 : scratchDistanceMatrix[i, j - 1] + 1;
                    int substitution = (i == 0 || j == 0) ? cost : scratchDistanceMatrix[i - 1, j - 1] + cost;
                    scratchDistanceMatrix[i, j] = Math.Min(Math.Min(deletion, insertion), substitution);
                    // Check for Transposition  
                    if (i > 1 && j > 1 && (str1[str1Index] == str2[str2Index - 1]) &&
                        (str1[str1Index - 1] == str2[str2Index]))
                    {
                        scratchDistanceMatrix[i, j] = Math.Min(
                            scratchDistanceMatrix[i, j], scratchDistanceMatrix[i - 2, j - 2] + cost);
                    }
                }
            }
            // Levenshtein distance is the bottom right element       
            return scratchDistanceMatrix[str1.Length, str2.Length];
        }

        #endregion
    }
    public class SystemInfo
    {
        private long pcCpuLoad;   //CPU计数器
        //private float pcCpuLoad2;
        //private PerformanceCounter pcCpuLoad1;
        //private int m_ProcessorCount = 0;   //CPU个数
        //private long m_PhysicalMemory = 0;   //物理内存
        public long getCpu()
        {
            //pcCpuLoad1 = new PerformanceCounter("Processor", "% Idle Time", "_Total");
            //pcCpuLoad1.NextValue();
            //double cpuTime = 0;
            //Process[] MyProcesses = Process.GetProcesses();
            //foreach (Process MyProcess in MyProcesses)
            //{
            //    try
            //    {
            //        //cpuTime = MyProcess.TotalProcessorTime.TotalSeconds + cpuTime;
            //        pcCpuLoad1 = new PerformanceCounter("Processor", "% Processor Time", MyProcess.ProcessName);
            //        pcCpuLoad2 = pcCpuLoad2+pcCpuLoad1.NextValue();
            //    }
            //    catch
            //    {
            //        continue;
            //    }

            //}



            ManagementObjectSearcher searcher = new ManagementObjectSearcher("root\\CIMV2",
                    "SELECT * FROM Win32_PerfFormattedData_Counters_ProcessorInformation");
            var cpuTimes = searcher.Get()
                .Cast<ManagementObject>()
                .Select(mo => new
                {
                    Name = mo["Name"],
                    Usage = mo["PercentProcessorTime"]
                }
                )
                .ToList();


            var query = cpuTimes.Where(x => x.Name.ToString() == "_Total").Select(x => x.Usage);
            List<object>item = cpuTimes.Select(x => x.Usage).ToList();
            foreach(object a in item)
            {
                Console.WriteLine(a);
            }
            Console.WriteLine(item[item.Count-3]);
            var cpuUsage = query.SingleOrDefault();
            return pcCpuLoad = Convert.ToInt32(cpuUsage);

         
            //pcCpuLoad = new PerformanceCounter("Processor", "% Processor Time", "_Total");
        }
        public double CpuLoad
        {
            get
            {
                return getCpu();
            }
        }
      

    }
    //public class RestClient
    //{
    //    private string BaseUri;
    //    private AutoResetEvent myEvents;
    //    public RestClient(string baseUri, AutoResetEvent myEvent)
    //    {
    //        this.BaseUri = baseUri;
    //        this.myEvents = myEvent;
    //    }
    //    public void Get(object a)
    //    {
    //        //先根据用户请求的uri构造请求地址
    //        string serviceUrl = this.BaseUri;
    //        ServicePointManager.ServerCertificateValidationCallback += (s, cert, chain, sslPolicyErrors) => true;
    //        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
    //        //创建Web访问对  象
    //        HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(serviceUrl);
    //        //通过Web访问对象获取响应内容
    //        HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
    //        //通过响应内容流创建StreamReader对象，因为StreamReader更高级更快
    //        StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);
    //        //string returnXml = HttpUtility.UrlDecode(reader.ReadToEnd());//如果有编码问题就用这个方法
    //        string returnXml = reader.ReadToEnd();//利用StreamReader就可以从响应内容从头读到尾
    //        reader.Close();
    //        myResponse.Close();
    //        myEvents.Set();
    //        //return returnXml;
    //    }
    //}
    //public class ttest
    //{
    //    public AutoResetEvent myEvents;
    //    public ttest(AutoResetEvent myEvent)
    //    {
    //        myEvents = myEvent;
    //    }

    //}
    class Program
    {

        //static string BaseUri = "https://192.168.1.141:5001/test";
        //private AutoResetEvent myEvents;
        private static object locker = new object();//创建锁
        static int acc = 0;
        public class UpdateVisitor : IVisitor
        {
             public void VisitComputer(IComputer computer)
             {
                 computer.Traverse(this);
             }
             public void VisitHardware(IHardware hardware)
             {
                 hardware.Update();
                 foreach (IHardware subHardware in hardware.SubHardware) subHardware.Accept(this);
             }
             public void VisitSensor(ISensor sensor) { }
             public void VisitParameter(IParameter parameter) { }
        }
        static double GetSystemInfo()
        {
            UpdateVisitor updateVisitor = new UpdateVisitor();
            Computer computer = new Computer();
            computer.Open();
            computer.CPUEnabled = true;
            computer.Accept(updateVisitor);
            for (int i = 0; i < computer.Hardware.Length; i++)
            {
                if (computer.Hardware[i].HardwareType == HardwareType.CPU)
                {
                    for (int j = 0; j < computer.Hardware[i].Sensors.Length; j++)
                    {
                        if (computer.Hardware[i].Sensors[j].SensorType == SensorType.Temperature)
                        {
                            Console.WriteLine(computer.Hardware[i].Sensors[j].Name + ":" + computer.Hardware[i].Sensors[j].Value.ToString() + "\r");
                            return (double)computer.Hardware[i].Sensors[j].Value;
                        }
                           
                    }
                }
            }
            return 0;
            computer.Close();
        }
        //public static void Get(object a)
        //{

        //    //先根据用户请求的uri构造请求地址
        //    //string serviceUrl = Program.BaseUri;
        //    ServicePointManager.ServerCertificateValidationCallback += (s, cert, chain, sslPolicyErrors) => true;
        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //    //创建Web访问对  象
        //    HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create("https://192.168.1.141:5001/test");
        //    //通过Web访问对象获取响应内容
        //    HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
        //    //通过响应内容流创建StreamReader对象，因为StreamReader更高级更快
        //    StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);
        //    //string returnXml = HttpUtility.UrlDecode(reader.ReadToEnd());//如果有编码问题就用这个方法
        //    string returnXml = reader.ReadToEnd();//利用StreamReader就可以从响应内容从头读到尾
        //    reader.Close();
        //    myResponse.Close();
        //    while (true)
        //    {
        //        lock (locker)//加锁
        //        {
        //            acc = acc + 1;
        //            break;
        //        }
        //    }

        //    //myEvents.Set();
        //    //return returnXml;
        //}
        static AutoResetEvent myEvent = new AutoResetEvent(false);
        public static void tht()
        {
            //SystemInfo sys = new SystemInfo();
            ThreadPool.SetMinThreads(1, 1);
            ThreadPool.SetMaxThreads(20, 20);
            //Program.BaseUri = "https://192.168.1.141:5001/test";
            for (int i = 1; i <= 10; i++)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback(testadd), i);
            }

        }

        //  浮点测试
        private static int QSet(float xx, float yy, float u, float v)
        {
            int n;
            float t, xsqr, ysqr;
            int lim = 100;
            float x = xx;
            float y = yy;
            xsqr = x * x;
            ysqr = y * y;
            for (n = 0; (n < lim) && (xsqr + ysqr < 4.0); n++)
            {
                t = xsqr - ysqr + u;
                y = 2.0f * x * y + v;
                x = t;
                xsqr = t * t;
                ysqr = y * y;
            }
            return n;
        }

        private static int MB100()
        {
            int dots = 0;
            int res = 100;
            float a1 = -2.50f;
            float b1 = -1.75f;
            float s = 3.05f;
            float x = 0;
            float y = 0;
            float g = s / res;
            int i, j, k;
            float a, b;

            for (j = 0, b = b1; j < res; b += g, j++)
            {
                for (i = 0, a = a1; i < res; a += g, i++)
                {
                    k = QSet(x, y, a, b);
                    if (k > 90)
                    {
                        dots++;
                    }
                }
            }
            return dots;
        }
        //字符串排序
        public static void stringSort(object obj)
        {
            int threadIndex = (int)obj;
            Console.WriteLine($"Thread {threadIndex} started...");


            const long count = 100;
            const int length = 100;
            var strlist = new string[count];
            string comparestring = StringDistance.GenerateRandomString(length);
            var steps = new int[count];
            Parallel.For(0, count, i => strlist[i] = StringDistance.GenerateRandomString(length));
            for (int i = 0; i < count; i++)
            {
                steps[i] = StringDistance.LevenshteinDistance(comparestring, strlist[i]);
            }

            while (true)
            {
                lock (locker)//加锁
                {

                    acc = acc + 1;
                    Console.WriteLine($"Thread {threadIndex} finished...{acc}");
                    break;
                }
            }
        }
        public static  void testadd(object obj)
        {
            int threadIndex = (int)obj;
            Console.WriteLine($"Thread {threadIndex} started...");
            
            long a = 1;
            for (long n = 0; n <= 20000000; n++)
            {
                a = a + n;
                a = a * a;
            }

            //for (int i = 0; i < 100; i++)
            //{
            //    MB100();
            //}
            //acc = acc + 1;
            //Console.WriteLine($"Thread {threadIndex} finished...{acc}");
            while (true)
            {
                lock (locker)//加锁
                {

                    acc = acc + 1;
                    Console.WriteLine($"Thread {threadIndex} finished...{acc}");
                    break;
                }
            }
            //return a;
        }
        //public static double GetNCZYL()
        //{

        //    double zyl = (GetNC() - GetKYNC()) / GetNC() * 100;
        //    return Math.Round(zyl, 2);
        //}


        //public static double GetKYNC()
        //{
        //    double totalCapacity = 0;
        //    ObjectQuery objectQuery = new ObjectQuery("select * from Win32_PerfRawData_PerfOS_Memory");
        //    ManagementObjectSearcher searcher = new
        //   ManagementObjectSearcher(objectQuery);
        //    ManagementObjectCollection vals = searcher.Get();
        //    foreach (ManagementObject val in vals)
        //    {
        //        totalCapacity += System.Convert.ToDouble(val.GetPropertyValue("Availablebytes"));
        //    }
        //    double ramCapacity = totalCapacity / 1048576;
        //    return ramCapacity;
        //}

        //public static double GetNC()
        //{
        //    double  totalCapacity = 0;
        //    ObjectQuery objectQuery = new ObjectQuery("select * from Win32_PhysicalMemory");
        //    ManagementObjectSearcher searcher = new
        //    ManagementObjectSearcher(objectQuery);
        //    ManagementObjectCollection vals = searcher.Get();
        //    foreach (ManagementObject val in vals)
        //    {
        //        totalCapacity += System.Convert.ToDouble(val.GetPropertyValue("Capacity"));
        //    }
        //    double ramCapacity = totalCapacity / 1048576;
        //    return ramCapacity;
        //}
        static  void  recoding(double[,] a,string fileName)
        {
            using (StreamWriter sw = new StreamWriter(fileName + ".txt", true, Encoding.UTF8))
            {
                for (int n = 0; n < a.Length/3; n++)
                {
                    sw.WriteLine(a[n, 2] + "     " + a[n, 0]);
                }

            }            
        }
        static void Main(string[] args)
        {
            string fileName = "1";

            if (args.Length !=0)
            {
                fileName = args[0];
            }
            
            Console.WriteLine(fileName);
            //ThreadPool.SetMinThreads(1, 1);
            //ThreadPool.SetMaxThreads(10, 10);
            System.Diagnostics.Stopwatch oTime = new System.Diagnostics.Stopwatch();
            //List<double> Timeinfo = new List<double>();
            //int count = 0;
            //int st = 0;
            int ac = 0;
            //ttest tt = new ttest(myEvent);
            //Thread[] taskArray = new Thread[8];
            //SystemInfo sys = new SystemInfo();
            //List<Dictionary<string, float>> list = new List< Dictionary<string, float>>();
            //Dictionary<string, float> dic = new Dictionary<string, float>();
            double[,] a = new double[20, 3];
            //RestClient getrq = new RestClient("https://localhost:49693//test");
            Thread.Sleep(60000);
            SystemInfo sys = new SystemInfo();

                for (int p = 0; p < 20; p++)
                {
                    Thread.Sleep(60000);

                    //sw.WriteLine("内存使用率：" + GetNCZYL() + "%");
                    //var obj = new ManagementObjectSearcher("select * from Win32_PhysicalMemory");

                    //ManagementObjectSearcher searcher = new ManagementObjectSearcher("select * from Win32_PerfFormattedData_PerfOS_Processor");
                    //var cpuTimes = searcher.Get()
                    //    .Cast<ManagementObject>()
                    //    .Select(mo => new
                    //    {
                    //        Name = mo["Name"],
                    //        Usage = mo["PercentProcessorTime"]
                    //    }
                    //    )
                    //    .ToList();

                    //double aa = sys.CpuLoad;
                    //if (aa <= 30 & aa!=0)
                    //{
                    //    count = count + 1;
                    //}
                    //else
                    //{
                    //    count = 0;
                    //}
                    //if(count < 2) 
                    //{ continue; }
                    //var query = cpuTimes.Where(x => x.Name.ToString() == "_Total").Select(x => x.Usage);
                    //sw.WriteLine("cpu使用率：" + sys.CpuLoad + "%");

                    //a[ac, 1] = sys.CpuLoad;

                    if (ac == 0)
                    {
                        double aa = 0;
                        for (int q = 0; q < 20; q++)
                        {
                            aa = sys.CpuLoad;
                            a[q, 0] = aa;
                            a[q, 1] = GetSystemInfo();
                            Thread.Sleep(1000);
                        }
                        Thread.Sleep(60000);
                    }

                    oTime.Start();
                    //var bb = getrq.Get();
                    //sys.Ttest(taskArray);
                    tht();
                    while (true)
                    {
                        if (acc == 10)
                        {
                            acc = 0;
                            break;
                        }
                    }
                    //myEvent.WaitOne();
                    oTime.Stop();
                    //a[ac, 0] = GetNCZYL();

                    //Timeinfo.Add(oTime.Elapsed.TotalMilliseconds);
                    a[ac, 2] = oTime.Elapsed.TotalMilliseconds;
                    ac = ac + 1;
                    oTime.Reset();
                    //dic.Add(GetNCZYL(), sys.CpuLoad);


                    Thread.Sleep(1000);
                    if (ac == 19)
                    {
                    //break;
                    recoding(a, fileName);
                    //recoding(a, "1");
                    ac = 0;

                    }
                }
            
            
            
            //using ( StreamWriter sw = new StreamWriter(DateTime.Now.ToString(), true, Encoding.UTF8))
            //{
            //    for (int n = 0;n<a.Length/3;n++)
            //    {
            //        sw.WriteLine(a[n, 2] + "     " + a[n,0]);
            //    }

            //}

        }
    }
}
